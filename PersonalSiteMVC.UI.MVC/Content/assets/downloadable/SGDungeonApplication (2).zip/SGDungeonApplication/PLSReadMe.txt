Just double click to run the application! (Not the config or the program debug)

TODO: Description of the App, how to use the app